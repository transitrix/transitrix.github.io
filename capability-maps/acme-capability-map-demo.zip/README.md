# Acme capability-map teaching example

Extract this archive and open acme-capability-map.html in a browser. No server
or network is needed. All snapshots are included in this file.

Compare Classic and Sort by layers. Select MDM, Data Hub, Governance Portal
and Warehouse System, then enable Coverage polygons and Functional overlap.
Move the timeline from October 2026 to January 2027. Use Diagram only and Fit
to screen; Show controls or Escape restores the controls. Download SVG saves
the exact selected view.

The data extends the public Acme example with visibly labelled illustrative
capabilities and mappings. Historical/current/planned periods are teaching
scenarios, not reconstructed observations or promised deployments. Red is the
geometric region inside two or more outer system polygons, not proof of
redundant functions. Missing mappings mean not specified.

Renderer 6.8.2; adapter dsm-capability-html/6. Methodology source correction:
888c03d33c2d899ec85a612901075b67811614e5 (merged, not tagged as a release).
Original Acme source: https://github.com/transitrix/acme-corp/tree/e331590b13935d1d0922063acbf1f6a0cb3cdba2
The skill archive contains the source/illustration notes and input contract.
